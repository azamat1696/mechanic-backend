/* eslint-disable prettier/prettier */
import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
  OneToOne,
} from 'typeorm';

// Entities
import { Merchant } from '../merchants/merchant.entity';
import { OrderDetail } from '../order-detail/order-detail.entity';

@Entity()
export class Order {
  @PrimaryGeneratedColumn()
  id: number;

  // Order => Merchant
  @ManyToOne(() => Merchant, (merchant) => merchant.order)
  merchant: Merchant;

  @OneToOne(() => OrderDetail, (orderDetail) => orderDetail.order, {
    // cascade: true,
    onDelete: 'CASCADE',
  })
  orderDetail: OrderDetail;

  @Column()
  name: string;

  @Column()
  description: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;

  @Column({ default: true, name: 'Active' })
  isActive: boolean;
}
