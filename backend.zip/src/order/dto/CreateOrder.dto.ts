/* eslint-disable prettier/prettier */
import {
  IsBoolean,
  IsNotEmpty,
  IsString,
  MinLength,
  IsInt,
  IsNumber,
  IsArray,
  IsEnum,
} from 'class-validator';

import { OrderType } from '../../order-detail/order-detail.entity';

export class CreateOrderDto {
  @IsString()
  @IsNotEmpty()
  @MinLength(5)
  name: string;

  @IsString()
  @IsEnum(OrderType)
  @IsNotEmpty()
  @MinLength(2)
  Type: OrderType;

  @IsString()
  @IsNotEmpty()
  @MinLength(5)
  description: string;

  @IsInt()
  @IsNumber()
  merchantId: number;

  @IsBoolean()
  @IsNotEmpty()
  isActive: boolean;
}
