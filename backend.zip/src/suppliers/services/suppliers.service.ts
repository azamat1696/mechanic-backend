/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

// Entities
import { Supplier } from '../supplier.entity';

// Dto
import { CreateSupplierDto } from '../dto/create.dto';
import { UpdateSupplierDto } from '../dto/update.dto';

@Injectable()
export class SupplierService {
  constructor(
    @InjectRepository(Supplier)
    private supplierRepository: Repository<Supplier>
  ) {}

  async create(createSupplierDto: CreateSupplierDto, merchant: any) {
    console.log('createSupplierDto', createSupplierDto);

    const supplier = this.supplierRepository.create({
      ...createSupplierDto,
      merchant,
    });

    return await this.supplierRepository.save(supplier);
  }

  findAll() {
    return `This action returns all test`;
  }

  async findOne(id: number) {
    console.log('supplier id', id);
    return await this.supplierRepository.findOneBy({ id });
  }

  update(id: number, updateSupplierDto: UpdateSupplierDto) {
    return `This action updates a #${id} test`;
  }

  remove(id: number) {
    return `This action removes a #${id} test`;
  }
}
