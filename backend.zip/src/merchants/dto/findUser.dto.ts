/* eslint-disable prettier/prettier */

export class FindUserDto {
  id: number;
}
