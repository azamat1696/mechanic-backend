/* eslint-disable prettier/prettier */

export class MinimumStockEvent {
  productId: number;
}
