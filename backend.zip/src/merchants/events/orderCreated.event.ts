/* eslint-disable prettier/prettier */

export class OrderCreatedEvent {
  supplierId: number;
}
