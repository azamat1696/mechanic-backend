/* eslint-disable prettier/prettier */
import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Response,
  Body,
  UsePipes,
  ValidationPipe,
  Request,
  UseGuards,
  UseInterceptors,
  // UploadedFiles,
  UploadedFile,
} from '@nestjs/common';
import { DataSource } from 'typeorm';
import { FileInterceptor /*FilesInterceptor*/ } from '@nestjs/platform-express';
import { Express } from 'express';

// Services
import { MerchantsService } from '../services/merchants.service';
import { ProductService } from '../../products/services/product.service';
import { OrderService } from '../../order/services/order.service';
import { OrderDetailService } from '../../order-detail/services/order-detail.service';
import { OrderDetailToProductsService } from '../../orderDetailToProduct/services/orderDetailToProduct.service';
import { SupplierService } from '../../suppliers/services/suppliers.service';
import { PurchaseService } from '../../purchases/services/purchases.service';
import { UsersService } from '../../users/services/users.service';

// DTOs
import { UpdateMerchantsDto } from '../dto/update-merchant.dto';
import { CreateMerchantsDto } from '../dto/create-merchant.dto';
import { DeleteProductDto } from '../dto/deleteSingleProduct';
import { CreateOrderDto } from '../../order/dto/CreateOrder.dto';
import { CreateOrderDetail } from '../../order-detail/dto/createOrderDetail.dto';
import { CreateOrderDetailToProduct } from '../../orderDetailToProduct/dto/createOrderDetailToProduct.dto';
import { DeleteProductsDto } from '../dto/deleteProducts.dto';
import { AddProductsDto } from '../dto/addProducts.dto';
import { CreateSupplierDto } from '../../suppliers/dto/create.dto';
import { CreatePurchaseDto } from '../../purchases/dto/createPurchase.dto';
import { CreateProductDto } from '../../merchants/dto/createProduct.dto';
import { FindProductDto } from '../../products/dto/FindProduct.dto';
import { UpdateProductDto } from '../../products/dto/UpdateProduct.dto';
import { CreateUsersDto } from '../../users/dtos/CreateUsers.dto';
import { DeleteCustomerDto } from '../../merchants/dto/deleteCustomer';
import { UpdateUsersDto } from '../../users/dtos/UpdateUsers.dto';
import { FindUserDto } from '../../merchants/dto/findUser.dto';

// Guards
import { JwtAuthGuard } from '../../auth/guards/jwt-auth.guard';

// Entities
import { OrderDetailToProduct } from 'src/orderDetailToProduct/orderDetailToProduct.entity';

// Queries
import { queryStockByMerchant } from '../../db/queries/queries';

// DTO
import { GetMerchantDto } from '../dto/getMerchant.dto';
import { extname } from 'path';
import { diskStorage } from 'multer';
import { basename } from 'path';

@Controller('merchants')
export class MerchantsController {
  constructor(
    private readonly merchantsService: MerchantsService,
    private readonly productsService: ProductService,
    private readonly orderService: OrderService,
    private readonly orderDetailService: OrderDetailService,
    private readonly orderDetailToProductsService: OrderDetailToProductsService,
    private readonly suppliersService: SupplierService,
    private readonly purchaseService: PurchaseService,
    private readonly usersService: UsersService,
    private dataSource: DataSource
  ) {}

  // Get all merchants
  @Get()
  getUsers() {
    return this.merchantsService.findAll();
  }
  // Get all merchants

  // List products by merchant
  @Get('list-products')
  @UseGuards(JwtAuthGuard)
  async findMerchProducts(@Request() req, @Response() res) {
    const merchant = await this.merchantsService.findByEmail(req.user.email);
    const products = await this.productsService.getProductsByMerch(merchant);
    res.json({ products });
  }

  // Stock View
  @Post('stock')
  @UseGuards(JwtAuthGuard)
  async getData(@Body() getMerchantDto: GetMerchantDto) {
    const { merchantId: mId } = getMerchantDto;
    const stockView = await this.dataSource.query(
      queryStockByMerchant(Number(mId))
    );
    return stockView;
  }
  // Stock View

  // Get a single merchant
  // @Get(':id')
  // getMerchant(@Param('id') id: number) {
  //   return this.merchantsService.findOne(id);
  // }
  // Get a single merchant

  // Create merchant
  @Post('register')
  @UsePipes(ValidationPipe)
  createMerchant(@Body() createMerchantsDto: CreateMerchantsDto) {
    console.log('Password', createMerchantsDto.password);
    return this.merchantsService.add(createMerchantsDto);
  }
  // Create merchant

  // Update merchant
  @Put(':id')
  updateMerchant(
    @Param('id') id: number,
    @Body() updateMerchantDto: UpdateMerchantsDto
  ) {
    return this.merchantsService.update(id, updateMerchantDto);
  }
  // Update merchant

  // Delete merchant
  @Delete(':id')
  deleteMerchant(@Param('id') id: number) {
    return this.merchantsService.remove(id);
  }
  // Delete merchant

  // Merchant creates a product
  @Post('create-product')
  @UsePipes(ValidationPipe)
  @UseGuards(JwtAuthGuard)
  @UseInterceptors(
    FileInterceptor('photo', {
      storage: diskStorage({
        destination: './public/images',
        filename: function (req, image, cb) {
          const ext = extname(image.originalname);
          const uniqueSuffix =
            Date.now() + '-' + Math.round(Math.random() * 1e9);
          cb(null, image.fieldname + '-' + uniqueSuffix + ext);
        },
      }),
    })
  )
  async createProduct(
    @Body() createProductDto: CreateProductDto,
    @Request() req: any,
    @UploadedFile() file: Express.Multer.File,
    @Response() response: any
  ) {
    // console.log('request object', req.user);
    // console.log('req.body', req.body);
    console.log('createProductDto', createProductDto);
    // console.log('file', file);

    const { email } = req.user;
    const foundMerchant = await this.merchantsService.findByEmail(email);
    // console.log('foundMerchant', foundMerchant);

    if (foundMerchant) {
      console.log('createProductDto to ps', createProductDto);

      const image =
        `http://localhost:8000/public/` +
        basename('images') +
        `/${file.filename}`;

      const savedProduct = await this.productsService.add(foundMerchant, {
        ...createProductDto,
        image,
      });
      return response.json({ CreatedProduct: [savedProduct] });
    } else {
      return 'merchant not found';
    }
  }

  // Update product
  @Post('update-product')
  @UseGuards(JwtAuthGuard)
  @UseInterceptors(
    FileInterceptor('image', {
      storage: diskStorage({
        destination: './public/images',
        filename: function (req, image, cb) {
          const ext = extname(image.originalname);
          const uniqueSuffix =
            Date.now() + '-' + Math.round(Math.random() * 1e9);
          cb(null, image.fieldname + '-' + uniqueSuffix + ext);
        },
      }),
    })
  )
  async updateProduct(
    @Body() updateProductDto: UpdateProductDto,
    @Request() req: any,
    @UploadedFile() file: Express.Multer.File,
    @Response() response: any
  ) {
    // console.log('request object', req.user);
    console.log('req.body', req.body);
    console.log('updateProductDto', updateProductDto);
    console.log('file', file);
    const { id } = updateProductDto;

    let updatedProduct: any;

    console.log('updateProductDto', updateProductDto);

    if (file) {
      updatedProduct = await this.productsService.update(id, {
        ...updateProductDto,
        image:
          `http://localhost:8000/public/` +
          basename('images') +
          `/${file.filename}`,
      });
    } else {
      updatedProduct = await this.productsService.update(id, {
        ...updateProductDto,
      });
    }
    response.json({ UpdatedProduct: [updatedProduct] });
  }
  // Update product

  @Post('create-order')
  // @UsePipes(ValidationPipe)
  @UseGuards(JwtAuthGuard)
  async createOrder(
    @Body() createOrderDto: CreateOrderDto,
    @Body() createOrderDetail: CreateOrderDetail,
    @Body() createOrderDetailToProduct: CreateOrderDetailToProduct,
    @Request() req
  ) {
    const foundMerchant = await this.merchantsService.findByEmail(
      req.user.email
    );
    // console.log('req.user', req.user);
    // console.log('foundMerchant', foundMerchant);
    // console.log('request object', req.user);

    // Merchant found then add Order
    if (foundMerchant) {
      // check if order exists
      console.log('merchant', foundMerchant);
      // check if order exists
      const savedOrder = await this.orderService.add(
        foundMerchant,
        createOrderDto
      );

      // Find order once created and add OrderDetail
      const foundOrder = await this.orderService.findOne(savedOrder.id);
      const savedOrderDetail = await this.orderDetailService.add(
        foundOrder,
        createOrderDetail
      );

      // Find OrderDetail and add products used to OrderDetailToProducts
      if (savedOrderDetail) {
        console.log('savedOrderDetail', savedOrderDetail);
        const { id } = savedOrderDetail;
        const foundOrderDetail = await this.orderDetailService.findOne(id);
        console.log('foundOrderDetail', foundOrderDetail);
        console.log('create order product', createOrderDetailToProduct);

        const savedOrderDetailToProduct =
          await this.orderDetailToProductsService.add(
            foundOrderDetail,
            createOrderDetailToProduct
          );

        console.log('savedOrderDetailToProduct', savedOrderDetailToProduct);
      }

      return savedOrder;
    }
  }

  // Delete product from order
  @Post('delete-product')
  @UseGuards(JwtAuthGuard)
  async deleteProduct(@Body() deleteProductsDto: DeleteProductsDto) {
    // Get orderId from dto in request body
    console.log('deleteProductsDto', deleteProductsDto);

    const orderDetailToProduct = await this.dataSource
      .getRepository(OrderDetailToProduct)
      .createQueryBuilder()
      .select('o')
      .from(OrderDetailToProduct, 'o')
      .where({ orderDetail: deleteProductsDto.orderDetailId })
      .getMany();

    if (orderDetailToProduct) {
      // loop over current products array and remove products in dtoProducts array
      console.log('orderDetailToProduct', orderDetailToProduct);
      console.log('newArr', deleteProductsDto.products);

      return this.orderDetailToProductsService.deleteArrayOfProducts(
        deleteProductsDto.products
      );
    }
  }
  // Delete product from order

  // Add product to order
  @Post('add-product')
  @UseGuards(JwtAuthGuard)
  async addProductToOrder(@Body() addProductsDto: AddProductsDto) {
    console.log('addProductsDto', addProductsDto.products);

    const foundProducts = await this.productsService.findAll();

    const sProd = [];

    if (foundProducts) {
      addProductsDto.products.forEach((p) => {
        foundProducts.forEach((product) => {
          console.log('prod match? =>', product.id, p['id']);
          if (product.id === p['id']) {
            console.log('matching product', product);
            sProd.push(product);
          }
        });
      });
    }

    console.log('sProd', sProd);
    // return selectedProducts;

    const savedOrerDetailToProduct =
      await this.orderDetailToProductsService.add(
        addProductsDto.id,
        addProductsDto
      );

    return savedOrerDetailToProduct;

    return this.orderDetailToProductsService.addProducts(sProd);
    // console.log('orderDetailToProduct', orderDetailToProduct);
  }
  // Add product to order

  @Post('delete-order')
  @UseGuards(JwtAuthGuard)
  async deleteOrder(@Request() req) {
    console.log('req.body', req.body.id);
    return this.orderService.remove(req.body.id);
  }

  // Create Supplier
  @Post('create-supplier')
  @UseGuards(JwtAuthGuard)
  async createSupplier(@Body() createSupplierDto: CreateSupplierDto) {
    const merchant = await this.merchantsService.findOne(
      createSupplierDto.merchantId
    );

    merchant && console.log('merchant', merchant);
    return this.suppliersService.create(createSupplierDto, merchant);
  }
  // Create Supplier

  // Create Purchase
  @Post('create-purchase')
  @UseGuards(JwtAuthGuard)
  async createPurchase(@Body() createPurchaseDto: CreatePurchaseDto) {
    console.log('createPurchaseDto', createPurchaseDto);

    const { supplierId, productId } = createPurchaseDto;

    const supplier = await this.suppliersService.findOne(supplierId);
    const product = await this.productsService.findOne(productId);

    // return [supplier, product];
    if (supplier && product) {
      console.log('supplier', supplier);
      console.log('product', product);
      this.purchaseService.create(createPurchaseDto, product, supplier);
      // Purchase service
    }
  }
  // Create Purchase

  @Post('delete-single-product')
  @UseGuards(JwtAuthGuard)
  async deleteSingleProduct(@Body() deleteProductDto: DeleteProductDto) {
    return this.productsService.remove(Number(deleteProductDto.productId));
  }

  // Get Single Product
  @Post('product')
  @UseGuards(JwtAuthGuard)
  async findProduct(@Body() findProductDto: FindProductDto) {
    const { productId } = findProductDto;
    const foundProduct = await this.productsService.findOne(productId);
    return foundProduct;
  }
  // Get Single Product

  // Create a customer by merchant
  @Post('create-customer')
  @UseGuards(JwtAuthGuard)
  @UsePipes(ValidationPipe)
  async createCustomerByMerchant(
    @Request() req: any,
    @Response() res: any,
    @Body() createUsersDto: CreateUsersDto
  ) {
    // console.log('merchant', req.user.email);
    // console.log('createUsersDto', createUsersDto);
    const foundMerchant = await this.merchantsService.findByEmail(
      req.user.email
    );

    if (foundMerchant) {
      // create user
      const createdUser = await this.usersService.add(
        createUsersDto,
        foundMerchant
      );
      return res.json(createdUser);
    }
  }
  // Create a customer by merchant

  // Get All customers by merchant
  @Get('customers')
  @UseGuards(JwtAuthGuard)
  async getCustomersByMerchant(@Request() req: any, @Response() res: any) {
    const { email } = req.user;
    const merch = await this.merchantsService.findByEmail(email);
    if (merch) {
      const cust = await this.usersService.findCustomersByMerchant(merch.id);
      return res.json(cust);
    }
  }

  // Delete Customer
  @Post('delete-customer')
  @UseGuards(JwtAuthGuard)
  async deleteCustomerByMerchant(
    @Body() deleteCustomerDto: DeleteCustomerDto,
    @Request() req: any,
    @Response() res: any
  ) {
    console.log('deleteCustomerDto', deleteCustomerDto);
    const deletedUser = await this.usersService.remove(
      deleteCustomerDto.customerId
    );
    res.json({ deletedUser });
  }
  // Delete Customer

  // Update Customer
  @Post('update-customer')
  @UseGuards(JwtAuthGuard)
  async updateCustomerByMerchant(
    @Body() updateUsersDto: UpdateUsersDto,
    @Request() req: any,
    @Response() res: any
  ) {
    console.log('updateUsersDto', updateUsersDto);
    return;
  }
  // Update Customer

  @Post('update-customer')
  @UseGuards(JwtAuthGuard)
  async findSingleCustomer(
    @Body() findUserDto: FindUserDto,
    @Request() req: any,
    @Response() res: any
  ) {
    console.log('findUserDto', findUserDto);
    // res.json({ customerId: findUserDto.id });
    // return this.usersService.findOne(findUserDto.id);
  }
}
