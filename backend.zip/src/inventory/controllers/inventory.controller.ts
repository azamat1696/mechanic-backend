/* eslint-disable prettier/prettier */
import {
  Controller,
  Get,
  //   Post,
  //   Put,
  //   Delete,
  //   Param,
  //   Body,
  //   UsePipes,
  //   ValidationPipe,
} from '@nestjs/common';
import { InventoryService } from '../services/inventory.service';

// DTOs
//   import { UpdateUsersDto } from '../dtos/UpdateUsers.dto';
//   import { CreateUsersDto } from '../dtos/CreateUsers.dto';

@Controller('inventory')
export class InventoryController {
  constructor(private readonly inventoryService: InventoryService) {}
  // Get all Inventory
  @Get()
  getUsers() {
    return this.inventoryService.findAll();
  }

  // Get a single Inventory
  // @Get(':id')
  // getUser(@Param('id') id: number) {
  //   return this.usersService.findOne(id);
  // }

  // Create user
  //   @Post()
  //   @UsePipes(ValidationPipe)
  //   createUser(@Body() createUsersDto: CreateUsersDto) {
  //     console.log('Password', createUsersDto.password);
  //     return this.usersService.add(createUsersDto);
  //   }

  // Update user
  //   @Put(':id')
  //   updateUser(@Param('id') id: number, @Body() updateUsersDto: UpdateUsersDto) {
  //     return this.usersService.update(id, updateUsersDto);
  //   }

  // Delete user
  //   @Delete(':id')
  //   deleteUser(@Param('id') id: number) {
  //     return this.usersService.remove(id);
  //   }
}
