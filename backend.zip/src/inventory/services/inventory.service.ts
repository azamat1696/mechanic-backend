/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

// Entities
import { Inventory } from '../inventory.entity';

// Dtos
// import { CreateJobDto } from '../dto/CreateJob.dto';
// import { UpdateJobDto } from '../dto/UpdateJob.dto';

@Injectable()
export class InventoryService {
  constructor(
    @InjectRepository(Inventory)
    private inventoryRepository: Repository<Inventory>
  ) {}

  async findAll() {
    return await this.inventoryRepository.find();
  }

  async findOne(id: number) {
    return await this.inventoryRepository.findOneBy({ id });
  }

  // async findByUser(id: number) {
  //   return await this.jobsRepository.find({
  //     where: {
  //       userId: id,
  //     },
  //   });
  // }

  //   async remove(id: number) {
  //     return await this.jobsRepository.delete(id);
  //   }

  // async add(createJobDto: CreateJobDto) {
  //   const newJob = this.jobsRepository.create(createJobDto);
  //   return this.jobsRepository.save(newJob);
  // }

  //   async update(id: number, updateJobDto: UpdateJobDto) {
  //     const updatedJob = await this.jobsRepository.update(id, updateJobDto);
  //     if (updatedJob) {
  //       return updatedJob;
  //     }
  //   }
}
