/* eslint-disable prettier/prettier */
import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
} from 'typeorm';

import { Product } from '../products/product.entity';
// import { Merchant } from '../merchants/merchant.entity';

@Entity()
export class Inventory {
  @PrimaryGeneratedColumn()
  id: number;

  // Inventory => Product
  @ManyToOne(() => Product, (product) => product.inventory, {
    eager: true,
    cascade: false,
    nullable: false,
  })
  product: Product[];

  @Column()
  quantity: number;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;
}
