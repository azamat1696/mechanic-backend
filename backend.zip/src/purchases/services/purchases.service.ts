/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

// Entities
import { Purchase } from '../../purchases/purchase.entity';

// Dto
import { CreatePurchaseDto } from '../dto/createPurchase.dto';

@Injectable()
export class PurchaseService {
  constructor(
    @InjectRepository(Purchase)
    private purchaseRepository: Repository<Purchase>
  ) {}

  async create(
    createPurchaseDto: CreatePurchaseDto,
    product: any,
    supplier: any
  ) {
    console.log('createPurchaseDto', createPurchaseDto);

    const purchase = this.purchaseRepository.create({
      ...createPurchaseDto,
      product,
      supplier,
    });

    return await this.purchaseRepository.save(purchase);
  }

  //   findAll() {
  //     return `This action returns all test`;
  //   }

  //   findOne(id: number) {
  //     return `This action returns a #${id} test`;
  //   }

  //   update(id: number, updateSupplierDto: UpdateSupplierDto) {
  //     return `This action updates a #${id} test`;
  //   }

  //   remove(id: number) {
  //     return `This action removes a #${id} test`;
  //   }
}
