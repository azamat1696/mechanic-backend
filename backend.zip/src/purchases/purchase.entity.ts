/* eslint-disable prettier/prettier */
import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
} from 'typeorm';

// Entities
import { Supplier } from '../suppliers/supplier.entity';
import { Product } from '../products/product.entity';

@Entity()
export class Purchase {
  @PrimaryGeneratedColumn()
  id: number;

  // Purchase => Supplier
  @ManyToOne(() => Supplier, (suppliers) => suppliers.purchase)
  supplier: Supplier;

  // Purchase => Product
  @ManyToOne(() => Product, (product) => product.purchase)
  product: Product;

  @Column()
  purchase_quantity: number;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;
}
