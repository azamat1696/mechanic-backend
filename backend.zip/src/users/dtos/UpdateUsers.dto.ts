/* eslint-disable prettier/prettier */

export class UpdateUsersDto {
  firstName: string;
  lastName: string;
  email: string;
  telephone: string;
}
