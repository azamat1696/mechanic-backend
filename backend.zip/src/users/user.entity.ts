/* eslint-disable prettier/prettier */
import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
} from 'typeorm';
// import { Exclude } from 'class-transformer';
import { Merchant } from '../merchants/merchant.entity';

@Entity()
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  firstName: string;

  @Column()
  lastName: string;

  @Column()
  email: string;

  @Column()
  telephone: string;

  // @Exclude()
  // @Column()
  // password: string;

  // Product => Merchant
  // @ManyToOne(() => Merchant, (merchant) => merchant.products, {
  //   eager: true,
  //   cascade: false,
  //   nullable: false,
  // })
  // merchant: Merchant;

  // @Column()
  // merchantId: number;

  // User => Merchant
  @ManyToOne(() => Merchant, (merchant) => merchant.user, {
    eager: true,
    cascade: false,
    nullable: true,
  })
  merchant: Merchant;

  @Column()
  merchantId: number;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;

  @Column({ default: true })
  isActive: boolean;
}
