/* eslint-disable prettier/prettier */
import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
} from 'typeorm';

// Entities
import { OrderDetail } from '../order-detail/order-detail.entity';
import { Product } from 'src/products/product.entity';

@Entity()
export class OrderDetailToProduct {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(
    () => OrderDetail,
    (orderDetail) => orderDetail.orderDetailToProduct
  )
  orderDetail: OrderDetail;

  // Product => OrderDetailToProduct
  @ManyToOne(() => Product, (product) => product.orderDetailToProduct)
  product: Product;

  @Column()
  quantity_used: number;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;
}
