/* eslint-disable prettier/prettier */
import { IsArray, IsNotEmpty } from 'class-validator';

export class CreateOrderDetailToProduct {
  @IsNotEmpty()
  @IsArray()
  products: [];

  @IsNotEmpty()
  quantity_used: number;
}
