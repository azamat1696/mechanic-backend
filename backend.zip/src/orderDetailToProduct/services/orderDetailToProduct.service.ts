/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

// Entities
import { OrderDetailToProduct } from '../orderDetailToProduct.entity';
import { Product } from '../../products/product.entity';

// DTO
import { CreateOrderDetailToProduct } from '../dto/createOrderDetailToProduct.dto';

// Services
import { ProductService } from '../../products/services/product.service';

@Injectable()
export class OrderDetailToProductsService {
  constructor(
    @InjectRepository(OrderDetailToProduct)
    private orderDetailToProductRepository: Repository<OrderDetailToProduct>,
    @InjectRepository(Product)
    private productRepository: Repository<Product>,
    private readonly productsService: ProductService
  ) {}

  //   async findAll() {
  //     return await this.orderRepository.find();
  //   }

  async findOne(id: any) {
    return await this.orderDetailToProductRepository.findOneBy({ id });
  }

  // async findByUser(id: number) {
  //   return await this.jobsRepository.find({
  //     where: {
  //       userId: id,
  //     },
  //   });
  //  }

  //   async remove(id: number) {
  //     return await this.orderRepository.delete(id);
  //   }

  // async add(createOrderDetail: CreateOrderDetail) {
  //   const newOrderDetail = this.orderDetailRepository.create(createOrderDetail);
  //   return await this.orderDetailRepository.save(newOrderDetail);
  // }

  async add(
    orderDetail: any,
    createOrderDetailToProduct: any
    // createOrderDetailToProduct: CreateOrderDetailToProduct
  ) {
    console.log('createOrderDetailToProduct', createOrderDetailToProduct);

    createOrderDetailToProduct.products.forEach(async (p: any) => {
      console.log('product from request body', p);

      // Find product
      const product = await this.productsService.findOne(p.id);
      console.log('foundProduct', product);

      // Create
      const newOrderDetailToProduct =
        this.orderDetailToProductRepository.create({
          orderDetail,
          product,
        });

      console.log('newOrderDetailToProduct', newOrderDetailToProduct);
      const savedOrderDetailToProduct =
        await this.orderDetailToProductRepository.save(newOrderDetailToProduct);
      console.log('savedOrderDetailToProduct', savedOrderDetailToProduct);
    });

    // x.products.forEach(async function (product) {
    //   console.log('product', product);
    //   // find product
    //   const newOrderDetailToProduct =
    //     await this.orderDetailToProductRepository.create({
    //       ...x,
    //       orderDetail,
    //       product,
    //     });
    //   //

    //   return await this.orderDetailToProductRepository.save(
    //     newOrderDetailToProduct
    //   );
    // });
  }

  async remove() {
    return;
  }

  async deleteArrayOfProducts(arr: any) {
    console.log('array', arr);
    return await this.orderDetailToProductRepository.delete(arr);
  }

  async addProducts(arr: any) {
    console.log('arr', arr);

    arr.forEach(async (product: any) => {
      await this.orderDetailToProductRepository.insert(product);
    });
    // return await this.orderDetailToProductRepository.insert(arr);
  }

  //   async update(id: number, updateJobDto: UpdateOrderDto) {
  //     const updatedJob = await this.orderRepository.update(id, updateJobDto);
  //     if (updatedJob) {
  //       return updatedJob;
  //     }
  //   }
}
