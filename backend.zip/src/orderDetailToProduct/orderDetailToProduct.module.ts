/* eslint-disable prettier/prettier */
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrderDetailToProductsService } from '../orderDetailToProduct/services/orderDetailToProduct.service';
import { Product } from '../products/product.entity';
import { ProductService } from '../products/services/product.service';
import { OrderDetailToProduct } from '../orderDetailToProduct/orderDetailToProduct.entity';
import { ProductStockOrderView } from '../products/productStockView.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      OrderDetailToProduct,
      Product,
      ProductStockOrderView,
    ]),
  ],
  providers: [OrderDetailToProductsService, ProductService],
  controllers: [],
  exports: [OrderDetailToProductsService],
})
export class OrderDetailToProductModule {}
