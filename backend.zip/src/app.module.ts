/* eslint-disable prettier/prettier */
import { Module } from '@nestjs/common';
import { UsersModule } from './users/users.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';

// Entities
import { User } from './users/user.entity';
import { Merchant } from './merchants/merchant.entity';
import { Order } from './order/order.entity';
import { Product } from './products/product.entity';
import { Inventory } from './inventory/inventory.entity';
import { OrderDetail } from './order-detail/order-detail.entity';
import { OrderDetailToProduct } from './orderDetailToProduct/orderDetailToProduct.entity';
import { Supplier } from './suppliers/supplier.entity';
import { Purchase } from './purchases/purchase.entity';

// Modules
import { AuthModule } from './auth/auth.module';
import { MerchantsModule } from './merchants/merchants.module';
import { OrderModule } from './order/order.module';
import { ProductModule } from './products/product.module';
import { InventoryModule } from './inventory/inventory.module';
import { OrderDetailModule } from './order-detail/order-detail.module';
import { OrderDetailToProductModule } from './orderDetailToProduct/orderDetailToProduct.module';
import { PurchaseModule } from './purchases/purchase.module';
import { SuppliersModule } from './suppliers/supplier.module';
import { ProductStockOrderView } from './products/productStockView.entity';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: 'localhost',
      port: 3306,
      username: 'halil',
      password: 'H@lilh2o',
      database: 'mechanic',
      entities: [
        User,
        Merchant,
        Order,
        Product,
        Inventory,
        OrderDetail,
        OrderDetailToProduct,
        Supplier,
        Purchase,
        ProductStockOrderView,
      ],
      synchronize: true,
    }),
    UsersModule,
    AuthModule,
    MerchantsModule,
    OrderModule,
    ProductModule,
    InventoryModule,
    OrderDetailModule,
    OrderDetailToProductModule,
    SuppliersModule,
    PurchaseModule,
    SuppliersModule,
  ],
  controllers: [],
  providers: [],
})
export class AppModule {
  constructor(private dataSource: DataSource) {}
}
