/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

// Entities
import { Product } from '../product.entity';
import { ProductStockOrderView } from '../productStockView.entity';

// Dtos
import { CreateProductDto } from '../../merchants/dto/createProduct.dto';

@Injectable()
export class ProductService {
  constructor(
    @InjectRepository(Product)
    private productRepository: Repository<Product>,
    @InjectRepository(ProductStockOrderView)
    private productStockOrderView: Repository<ProductStockOrderView>
  ) {}

  async findAll() {
    return await this.productRepository.find();
  }

  async findOne(id: number) {
    return await this.productRepository.findOneBy({ id });
  }

  async remove(id: number) {
    return await this.productRepository.delete(id);
  }

  async add(merchant: any, createProductDto: CreateProductDto) {
    const updatedCreateProductDto = {
      ...createProductDto,
      merchant,
      product_code: createProductDto.productCode,
    };
    console.log('updatedCreateProductDto', updatedCreateProductDto);
    const newProduct = this.productRepository.create(updatedCreateProductDto);
    console.log('newProduct', newProduct);
    return await this.productRepository.save(newProduct);
  }

  // Get products created by merchant
  async getProductsByMerch(merchant) {
    const id = merchant.id;
    const products = await this.productRepository.find({
      where: { merchantId: id },
    });
    return products;
  }

  async update(id: any, updateProductDto: any) {
    const foundProduct = await this.productRepository.findOneBy({ id });
    console.log('foundProduct', foundProduct);
    if (foundProduct) {
      const updatedProduct = await this.productRepository.update(id, {
        ...updateProductDto,
        // product_code: updateProductDto.productCode,
      });
      if (updatedProduct) {
        return await this.productRepository.findOneBy({ id });
      }
    }
  }
}
