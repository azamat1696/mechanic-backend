/* eslint-disable prettier/prettier */
import { ViewEntity, ViewColumn /*DataSource*/ } from 'typeorm';
// import { Product } from './product.entity';
// import { OrderDetailToProduct } from '../orderDetailToProduct/orderDetailToProduct.entity';
// import { Purchase } from '../purchases/purchase.entity';

@ViewEntity({
  expression: `
  SELECT  
  product.id as productId,
  product.merchantId as merchantId,
  product.name as name,
   
     (
      SELECT  
      SUM(purchase.purchase_quantity) 
      FROM purchase 
      WHERE purchase.productId = product.id) as reciepts,
      SUM(odtp.quantity_used) as sales,
    (
  
    (
      SELECT 
      SUM(purchase.purchase_quantity) 
      FROM purchase 
      WHERE purchase.productId = product.id) 
      -  
      SUM(odtp.quantity_used)
    ) as inStock
  
  FROM product
    LEFT JOIN order_detail_to_product odtp ON odtp.productId = product.id  
  
  GROUP BY product.id;
`,

  // expression: (dataSource: DataSource) =>
  //   dataSource
  //     .createQueryBuilder()
  //     .select('product.id')
  //     .addSelect('purchase.id', 'purchaseId')
  //     .addSelect('odtp.id', 'odtpId')
  //     .addSelect('SUM(purchase.purchase_quantity)', 'reciepts (12)')
  //     .addSelect('SUM(odtp.quantity_used)', 'sales (4)')
  //     .from(Product, 'product')
  //     .leftJoin(OrderDetailToProduct, 'odtp', 'product.id = odtp.productId')
  //     .leftJoin(Purchase, 'purchase', 'product.id = purchase.productId'),

  // .groupBy('odtp.productId'),
  // .groupBy('product.id'),
})
export class ProductStockOrderView {
  @ViewColumn()
  productId: number;

  @ViewColumn()
  merchantId: number;

  @ViewColumn()
  name: string;

  @ViewColumn()
  reciepts: number;

  @ViewColumn()
  sales: number;

  @ViewColumn()
  inStock: number;
}
