/* eslint-disable prettier/prettier */
import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
  OneToMany,
} from 'typeorm';

// Entities
import { Merchant } from '../merchants/merchant.entity';
import { Inventory } from 'src/inventory/inventory.entity';
import { OrderDetailToProduct } from '../orderDetailToProduct/orderDetailToProduct.entity';
import { Purchase } from '../purchases/purchase.entity';

@Entity()
export class Product {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column()
  manufacturer: string;

  // Product => Merchant
  @ManyToOne(() => Merchant, (merchant) => merchant.products, {
    eager: true,
    cascade: false,
    nullable: false,
  })
  merchant: Merchant;

  @Column()
  merchantId: number;

  // Product => Inventory
  @OneToMany(() => Inventory, (inventory) => inventory.product)
  inventory: Inventory;

  // Product => OrderDetailToProduct
  @OneToMany(
    () => OrderDetailToProduct,
    (orderDetailToProduct) => orderDetailToProduct.product
  )
  orderDetailToProduct: OrderDetailToProduct;

  // Product => Purchase
  @OneToMany(() => Purchase, (purchase) => purchase.supplier)
  purchase: Purchase;

  @Column()
  image: string;

  @Column()
  product_code: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;

  @Column({ default: true })
  isActive: boolean;
}
