/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

// Entities
import { OrderDetail } from '../order-detail.entity';

// DTO
import { CreateOrderDetail } from '../dto/createOrderDetail.dto';

@Injectable()
export class OrderDetailService {
  constructor(
    @InjectRepository(OrderDetail)
    private orderDetailRepository: Repository<OrderDetail>
  ) {}

  //   async findAll() {
  //     return await this.orderRepository.find();
  //   }

  async findOne(id: any) {
    return await this.orderDetailRepository.findOneBy({ id });
  }

  // async findByUser(id: number) {
  //   return await this.jobsRepository.find({
  //     where: {
  //       userId: id,
  //     },
  //   });
  //  }

  //   async remove(id: number) {
  //     return await this.orderRepository.delete(id);
  //   }

  // async add(createOrderDetail: CreateOrderDetail) {
  //   const newOrderDetail = this.orderDetailRepository.create(createOrderDetail);
  //   return await this.orderDetailRepository.save(newOrderDetail);
  // }

  async add(order: any, createOrderDetail: CreateOrderDetail) {
    //
    const newOrderDetail = this.orderDetailRepository.create({
      ...createOrderDetail,
      order,
    });
    //
    const savedOrderDetail = await this.orderDetailRepository.save(
      newOrderDetail
    );
    //
    return savedOrderDetail;
  }

  //   async update(id: number, updateJobDto: UpdateOrderDto) {
  //     const updatedJob = await this.orderRepository.update(id, updateJobDto);
  //     if (updatedJob) {
  //       return updatedJob;
  //     }
  //   }
}
