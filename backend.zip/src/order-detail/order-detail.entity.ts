/* eslint-disable prettier/prettier */
import {
  Entity,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  OneToOne,
  JoinColumn,
  OneToMany,
  Column,
} from 'typeorm';

// Entities
import { Order } from 'src/order/order.entity';
import { OrderDetailToProduct } from 'src/orderDetailToProduct/orderDetailToProduct.entity';

export enum OrderType {
  MECHANICAL = 'mechanic',
  BODYWORK = 'bodywork',
  ELECTRICAL = 'electrician',
}

@Entity()
export class OrderDetail {
  @PrimaryGeneratedColumn()
  id: number;

  // OrderDetail => Order
  @OneToOne(() => Order, (order) => order.orderDetail, {
    nullable: true,
    // cascade: true,
    onDelete: 'CASCADE',
  })
  @JoinColumn()
  order: Order;

  // OrderDetail => Product
  @OneToMany(
    () => OrderDetailToProduct,
    (orderDetailToProduct) => orderDetailToProduct.orderDetail,
    {
      cascade: true,
    }
  )
  orderDetailToProduct: OrderDetailToProduct[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;

  @Column({
    type: 'enum',
    enum: OrderType,
    default: OrderType.MECHANICAL,
  })
  Type: OrderType;
}
