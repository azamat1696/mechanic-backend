/* eslint-disable prettier/prettier */
import {
  IsString,
  IsEnum,
  MinLength,
  IsInt,
  IsNumber,
  IsNotEmpty,
} from 'class-validator';

import { OrderType } from '../order-detail.entity';

export class CreateOrderDetail {
  @IsString()
  @IsEnum(OrderType)
  @IsNotEmpty()
  @MinLength(2)
  Type: OrderType;

  @IsInt()
  @IsNumber()
  @IsNotEmpty()
  order_id: number;
}
